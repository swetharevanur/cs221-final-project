Script execution order:

1. Run lda_tuning.R to compute the optimal number of topics for LDA.
2. Change opt_num_topics accordingly on line 56 of lda.py.
3. Run lda.py.