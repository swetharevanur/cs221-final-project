Script execution order:

1. Run labeled_data.py to generate list of records to be manually labeled.
2. Manually label.

Label Spreading
1. Run label_spreading/label_spreading.py

Ladder Networks
1. Run ladder/ladder_net.py