# stopwords.py
# List of stop words
# Author: Swetha Revanur and Keanu Spies

ENGL_STOP_WORDS = ['i','a','about','an','are','as','at','be','by','for', 'am', 'and',\
				'from','how','is','it','of','on','or','that','the', \
				'this','to','was','what','when','where','who','will','with',\
				'losangeles', 'los', 'angeles', 'email', 'post', 'id', 'beverly', 'hills',\
				'google', 'map', u'\u2019', 'yahoo', 'if', 'do', 'not', 'contact']